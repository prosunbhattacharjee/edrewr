function takeValue(keypress) {
	document.getElementById('inputwindow').value += keypress;
}

