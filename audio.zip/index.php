<?php
session_start();

if(isset($_COOKIE['lginDtl'])){
    //echo $_COOKIE['lginDtl']; 
    $expld = explode(',',$_COOKIE['lginDtl']);
    $explode = explode('=',$expld[0]);
   //echo $explode[1]; die();
    $_SESSION['userSession'] = $explode[1];
}

if(isset($_SESSION['userSession'])):
    $con = mysqli_connect("localhost","digiaanj_emadmin","LALASS123!@#","digiaanj_eurekamagic");
    $insert = mysqli_query($con,"INSERT app_usage(user,app_name,time) VALUES('".mysqli_real_escape_string($con,$_SESSION['userSession'])."','pinx','".mysqli_real_escape_string($con,time())."')");
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Pinx</title>
    <!--  Bootstrap css    -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  

    <!-- style sheet -->
    <link href="css/pinx-style.css" rel="stylesheet" type="text/css">
    <!--        <script src="js/pinx.js" type="text/javascript"></script>-->

     <style>


        #element {
	margin: 0 auto;

	width: 100%;
	background-color: #e9e9e9;
	font-size: 20px;

	box-sizing: border-box;
}



/* webkit requires explicit width, height = 100% of sceeen */
/* webkit also takes margin into account in full screen also - so margin should be removed (otherwise black areas will be seen) */
#element:-webkit-full-screen {
	width: 100%;
	height: 100%;
	background-color: #fff;
	margin: 0;
}

#element:-moz-full-screen {
	background-color: #fff;
	margin: 0;
}

#element:-ms-fullscreen {
	background-color: #fff;
	margin: 0;
}

/* W3C proposal that will eventually come in all browsers */
#element:fullscreen { 
	background-color: #fff;
	margin: 0;
}


</style>
</head>

<body >
    <audio id="myAudio">
 
  <source src="audio/unlock.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio>
    <div id="element" style="background-color: #000">

    <div id="mainKeypad" class="wrapper" >
        <div class="container">
            <div class="row">
      



            </div>
            <div class="row text-center" style="position: fixed; left:0; right: 0; bottom: 0;">
                          <div class="col-sm-12">
                    <div class="inputPassword text-center">
                        <p id="shake" class="shake" onclick="getready()"></p>
                        <ul class="number-field">
                            <li><span id="dot1"></span></li>
                            <li><span id="dot2"></span></li>
                            <li><span id="dot3"></span></li>
                            <li><span id="dot4"></span></li>
                            <li> <img class="del img-responsive" src="images/del.png"  onclick="deletepin()"></li>
                        </ul>
                       
               
                    </div>




                </div>
                
                <div class="lockScreenKeypad">
                

                <!--              First Row-->
                <div class="col-xs-4"><button class="btn btn-key" id="one" value="1" onclick="takeValue(document.getElementById('one').value)">1</button></div>
                <div class="col-xs-4"><button class="btn btn-key" id="two" value="2" onclick="takeValue(document.getElementById('two').value)"> 2</button></div>
                <div class="col-xs-4"><button class="btn btn-key" id="three" value="3" onclick="takeValue(document.getElementById('three').value)"> 3</button></div>

                <!--                2nd Row-->
                <div class="col-xs-4"><button class="btn btn-key" id="four" value="4" onclick="takeValue(document.getElementById('four').value)"> 4</button></div>
                <div class="col-xs-4"><button class="btn btn-key" id="five" value="5" onclick="takeValue(document.getElementById('five').value)"> 5</button></div>
                <div class="col-xs-4"><button class="btn btn-key" id="six" value="6" onclick="takeValue(document.getElementById('six').value)"> 6</button></div>

                <!--            3rd Row-->
                <div class="col-xs-4"><button class="btn btn-key" id="seven" value="7" onclick="takeValue(document.getElementById('seven').value)"> 7</button></div>
                <div class="col-xs-4"><button class="btn btn-key" id="eight" value="8" onclick="takeValue(document.getElementById('eight').value)"> 8</button></div>
                <div class="col-xs-4"><button class="btn btn-key" id="nine" value="9" onclick="takeValue(document.getElementById('nine').value)"> 9</button></div>


                <!--            4th Row-->
                <div class="col-xs-4"></div>
                <div class="col-xs-4"><button class="btn btn-key" id="zero" value="0" onclick="takeValue(document.getElementById('zero').value)"> 0</button></div>
                <div class="col-xs-4"></div>
                
                
                </div>
                
            </div>
          
        </div>
      
    </div>
<!--    UnlocPage-->
      <div id="unlockPage" class="unlockPageWrapper" style="visibility: hidden; opacity: 0; -o-transition: visibility 0s, opacity 0.5s linear; -moz-transition: visibility 0s, opacity 0.5s linear; -webkit-transition: visibility 0s, opacity 0.5s linear; transition: visibility 0s, opacity 0.5s linear;">
       <div class="container">
          <div class="row">
                                  
<!--
                <div class="menuImage">
                    <img src="images/mobileMenu.png" class="img-responsive">
                    <small>1234</small>
                    </div>
-->
<div class="col-xs-12"><img src="images/menuicons/googlebar.png" class="img-responsive" style="width:100%; margin-top:30px; margin-bottom:60px"></div>
                          
<!--           End First Row-->
             <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/5.png" class="img-responsive"><span>Photo</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/6.png" class="img-responsive"><span>Music</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/7.png" class="img-responsive"><span>Notes</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img id="open-gallery" onclick="goToGallery()" src="images/menuicons/8.png" class="img-responsive"><span>Gallery</span></div>      </div> 
<!--              End Second Row-->
              
              <div class="col-xs-3"><div class="menuIcons pickedNo"><img src="images/menuicons/9.png" class="img-responsive"> <span>Screensho..</span> </div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/10.png" class="img-responsive"><span>VLC</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/11.png" class="img-responsive"><span>Uber</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/12.png" class="img-responsive"><span>Xender</span></div>      </div> 
<!--           End 3rd row-->
                  <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/17.png" class="img-responsive"><span>Facebook</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons" style="position:relative"><img src="images/menuicons/14.png" class="img-responsive"><small id="showFirstNo"></small><span>Weather</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/15.png" class="img-responsive"><span>Call</span></div>      </div>            
                <div class="col-xs-3"><div class="menuIcons"><img src="images/menuicons/20.png" class="img-responsive"><span>Twitter</span></div>      </div> 
<!--              End 4th Row-->
       
<!--              End 5th Row-->
              
           </div>
          </div>
       
       </div>
<!--    UnlocPage End-->
    
    <!--    Open Gallery-->
    <div id="gallery" class="openGallery" style="visibility: hidden; opacity: 0; -o-transition: visibility 0s, opacity 0.5s linear; -moz-transition: visibility 0s, opacity 0.5s linear; -webkit-transition: visibility 0s, opacity 0.5s linear; transition: visibility 0s, opacity 0.5s linear;">
   <img src="images/gallery.jpg" class="img-responsive" onclick="openDeck()">
       
       </div>
<!--    Open Gallery End-->
    
    
    <div id="deck" style="visibility: hidden; opacity: 0; -o-transition: visibility 0s, opacity 0.5s linear; -moz-transition: visibility 0s, opacity 0.5s linear; -webkit-transition: visibility 0s, opacity 0.5s linear; transition: visibility 0s, opacity 0.5s linear;">
      <div class="container">
       
          <div class="openNote">
   <img src="images/note.jpg" >
     
       <span class="showTxtdown" id="showPasss" ></span>
             
       </div>
       
       </div>
    </div>

    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>



    <script>
       
        var pin = "";
        var pinLength = "";
        var getSet = 0;
        var firstNo = "";
        var attempt = 0;
        var shake = 0;
        var lastNo = "";
        var x = document.getElementById("myAudio"); 

        function takeValue(keypress) {
            pin += keypress;
            pinLength = pin.length;
           

            if (pinLength >= 1) {
                document.getElementById('dot1').classList.add("active");
            }
            if (pinLength > 1) {
                document.getElementById('dot2').classList.add("active")
            }
            if (pinLength > 2) {
                document.getElementById('dot3').classList.add("active")
            }
            if (pinLength > 3) {
                document.getElementById('dot4').classList.add("active")
            }
            if (getSet == 0) {

                if (pinLength >= 4) {
                    document.getElementById('shake').classList.add("shake-vertical");
                    setTimeout(function() {
                        document.getElementById('shake').classList.remove("shake-vertical");

                    }, 500)


                    if (attempt == 0) {
                        firstNo = pin;
                    }

                    pin = "";
                    attempt++;
                    shake = 1;
                    document.getElementById('dot1').classList.remove("active");
                    document.getElementById('dot2').classList.remove("active");
                    document.getElementById('dot3').classList.remove("active");
                    document.getElementById('dot4').classList.remove("active");


                    document.getElementById('shake').innerHTML = "Wrong Pin.";




                }



            } else {
                if (pinLength >= 4) {
                    document.getElementById('mainKeypad').style.display = "none";
                     x.play();
                      document.getElementById('unlockPage').style.visibility = "visible";
                      document.getElementById('unlockPage').style.opacity = "1";
                    document.getElementById('showFirstNo').innerHTML = firstNo;
                    lastNo = pin;
                    console.log(firstNo);
                    console.log(lastNo);
                }
            }









        }



        function getready() {
            getSet = 1;
            document.getElementById('shake').innerHTML = "Wrong Pin..";

        }

        function deletepin() {

            pin = pin.slice(0, -1);
            pinLength = pin.length;
            if (pinLength == 2) {
                document.getElementById('dot3').classList.remove("active");
            }
            if (pinLength == 1) {
                document.getElementById('dot2').classList.remove("active");
            }
            if (pinLength == 0) {
                document.getElementById('dot1').classList.remove("active");
            }


        }
        
        
        
        function goToGallery(){
             document.getElementById('unlockPage').style.display = "none";
                      document.getElementById('gallery').style.visibility = "visible";
                      document.getElementById('gallery').style.opacity = "1";
                      document.getElementById('showPasss').innerHTML = "73854  0" + lastNo;
        }
        
        function openDeck(){
             document.getElementById('gallery').style.display = "none";
                      document.getElementById('deck').style.visibility = "visible";
                      document.getElementById('deck').style.opacity = "1";
        }
        
    </script>
    
    <script>
        var personname;
       
   
        var i = 1;



        /* Get into full screen */
        function GoInFullscreen(element) {
            if (element.requestFullscreen)
                element.requestFullscreen();
            else if (element.mozRequestFullScreen)
                element.mozRequestFullScreen();
            else if (element.webkitRequestFullscreen)
                element.webkitRequestFullscreen();
            else if (element.msRequestFullscreen)
                element.msRequestFullscreen();
        }

        /* Get out of full screen */
        //function GoOutFullscreen() {
        //	if(document.exitFullscreen)
        //		document.exitFullscreen();
        //	else if(document.mozCancelFullScreen)
        //		document.mozCancelFullScreen();
        //	else if(document.webkitExitFullscreen)
        //		document.webkitExitFullscreen();
        //	else if(document.msExitFullscreen)
        //		document.msExitFullscreen();
        //}

        /* Is currently in full screen or not */
        function IsFullScreenCurrently() {
            var full_screen_element = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement || null;

            // If no element is in full-screen
            if (full_screen_element === null)
                return false;
            else
                return true;
        }

        $("#element").on('click', function() {


            if (IsFullScreenCurrently())
                GoOutFullscreen();
            else
                GoInFullscreen($("#element").get(0));



        });




        $(document).on('fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange', function() {
            if (IsFullScreenCurrently()) {
                $("#element").addClass("fullscreen");


            } else {
                $("#element").removeClass("fullscreen");


            }
        });



    </script>




</body>

</html>
<?php 
else:
    header("Location: ../login.php?q=".base64_encode('perform/index.php'));
endif;
?>